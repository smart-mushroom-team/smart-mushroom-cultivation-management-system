"""FR-07, FR-08: Admin chỉnh sửa phòng/khay; Operator chỉ xem.

Quy tắc:
  * Ngừng phòng (INACTIVE) bị từ chối khi phòng còn khay RENTED (409 ROOM_HAS_RENTED_TRAYS).
  * Khay chỉ xóa được khi chưa từng thuộc đơn nào (kể cả đơn đã hoàn tất) để giữ lịch sử.
  * Không chuyển khay sang phòng khác khi đang RENTED.
"""
from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError

from common.db import engine
from common.errors import AppError
from common.security import CurrentUser, current_user, require_roles

router = APIRouter(tags=["rooms & trays"])


class RoomIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)


class RoomPatch(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=100)
    status: str | None = Field(default=None, pattern="^(ACTIVE|INACTIVE)$")


class TrayIn(BaseModel):
    trayCode: str = Field(min_length=1, max_length=50)
    roomId: str
    row: int = Field(ge=1, le=4)
    shelf: int = Field(ge=1, le=2)
    slot: int = Field(ge=1, le=4)


class TrayPatch(BaseModel):
    trayCode: str | None = Field(default=None, min_length=1, max_length=50)
    roomId: str | None = None
    row: int | None = Field(default=None, ge=1, le=4)
    shelf: int | None = Field(default=None, ge=1, le=2)
    slot: int | None = Field(default=None, ge=1, le=4)


def _room_row(r):
    return {"id": str(r.id), "name": r.name, "status": r.status}


@router.get("/rooms")
def list_rooms(_: CurrentUser = Depends(current_user)):
    with engine().connect() as c:
        return [_room_row(r) for r in c.execute(text("SELECT id,name,status FROM rooms ORDER BY name"))]


@router.get("/rental-availability", summary="Customer: sơ đồ khay khả dụng theo phòng")
def rental_availability(_=Depends(require_roles("CUSTOMER"))):
    """Chỉ trả phòng ACTIVE và khay/vị trí; không tiết lộ khách đang thuê."""
    with engine().connect() as c:
        rooms = c.execute(text("SELECT id,name FROM rooms WHERE status='ACTIVE' ORDER BY name")).all()
        trays = c.execute(text("""SELECT t.id,t.tray_code,t.room_id,t.location_row,t.location_shelf,
                                t.location_slot,t.occupancy_status
                                FROM trays t JOIN rooms r ON r.id=t.room_id
                                WHERE r.status='ACTIVE'
                                ORDER BY t.location_row,t.location_shelf,t.location_slot""")).all()
    by_room = {str(room.id): [] for room in rooms}
    for tray in trays:
        by_room[str(tray.room_id)].append({
            "id": str(tray.id), "code": tray.tray_code,
            "row": tray.location_row, "shelf": tray.location_shelf, "slot": tray.location_slot,
            "status": tray.occupancy_status,
        })
    result = []
    for room in rooms:
        items = by_room[str(room.id)]
        available = sum(t["status"] == "AVAILABLE" for t in items)
        rented = sum(t["status"] == "RENTED" for t in items)
        result.append({"id": str(room.id), "name": room.name,
                       "empty": 32 - len(items), "available": available,
                       "rented": rented, "other": len(items) - available - rented,
                       "trays": items})
    return result


@router.post("/rooms", status_code=201)
def create_room(body: RoomIn, _=Depends(require_roles("ADMIN"))):
    with engine().begin() as c:
        return {"id": str(c.execute(text("INSERT INTO rooms(name) VALUES (:n) RETURNING id"), {"n": body.name}).scalar())}


@router.patch("/rooms/{room_id}", summary="Sửa tên / ngừng hoặc bật lại phòng")
def update_room(room_id: str, body: RoomPatch, _=Depends(require_roles("ADMIN"))):
    with engine().begin() as c:
        room = c.execute(text("SELECT id,name,status FROM rooms WHERE id=:i FOR UPDATE"), {"i": room_id}).first()
        if not room:
            raise AppError(404, "ROOM_NOT_FOUND", "Phòng không tồn tại")
        if body.status == "INACTIVE" and room.status != "INACTIVE":
            rented = c.execute(text("SELECT count(*) FROM trays WHERE room_id=:i AND occupancy_status='RENTED'"),
                               {"i": room_id}).scalar()
            if rented:
                raise AppError(409, "ROOM_HAS_RENTED_TRAYS", f"Phòng còn {rented} khay đang được thuê, không thể ngừng")
        c.execute(text("UPDATE rooms SET name=COALESCE(:n,name), status=COALESCE(:s,status) WHERE id=:i"),
                  {"n": body.name, "s": body.status, "i": room_id})
        return _room_row(c.execute(text("SELECT id,name,status FROM rooms WHERE id=:i"), {"i": room_id}).first())


def _tray_row(r):
    return {"id": str(r.id), "tray_code": r.tray_code, "room_id": str(r.room_id), "location_row": r.location_row,
            "location_shelf": r.location_shelf, "location_slot": r.location_slot, "occupancy_status": r.occupancy_status}


_TRAY_COLS = "id,tray_code,room_id,location_row,location_shelf,location_slot,occupancy_status"


@router.get("/trays")
def list_trays(roomId: str | None = None, _=Depends(require_roles("OPERATOR"))):
    with engine().connect() as c:
        rows = c.execute(text(f"SELECT {_TRAY_COLS} FROM trays" + (" WHERE room_id=:r" if roomId else "") + " ORDER BY tray_code"),
                         {"r": roomId})
        return [_tray_row(r) for r in rows]


def _lock_room_positions(c, room_ids):
    """Serialize tray placement changes per room, including concurrent API requests."""
    for room_id in sorted(set(str(value) for value in room_ids)):
        c.execute(text("SELECT pg_advisory_xact_lock(hashtextextended(:room_id, 0))"), {"room_id": room_id})


def _ensure_position_empty(c, room_id, row, shelf, slot, exclude_tray_id=None):
    occupied = c.execute(text("""
        SELECT 1 FROM trays
        WHERE room_id = CAST(:room_id AS uuid)
          AND location_row = :row AND location_shelf = :shelf AND location_slot = :slot
          AND (CAST(:exclude_id AS uuid) IS NULL OR id <> CAST(:exclude_id AS uuid))
        LIMIT 1
    """), {"room_id": room_id, "row": row, "shelf": shelf, "slot": slot,
           "exclude_id": exclude_tray_id}).first()
    if occupied:
        raise AppError(409, "TRAY_POSITION_OCCUPIED", "Ô này đã có khay, vui lòng chọn ô khác")


@router.post("/trays", status_code=201)
def create_tray(body: TrayIn, _=Depends(require_roles("ADMIN"))):
    try:
        with engine().begin() as c:
            if not c.execute(text("SELECT 1 FROM rooms WHERE id=:i AND status='ACTIVE'"), {"i": body.roomId}).first():
                raise AppError(404, "ROOM_NOT_FOUND", "Phòng không tồn tại")
            _lock_room_positions(c, [body.roomId])
            _ensure_position_empty(c, body.roomId, body.row, body.shelf, body.slot)
            tid = c.execute(text("""INSERT INTO trays(tray_code,room_id,location_row,location_shelf,location_slot)
                                    VALUES (:c,:r,:a,:b,:d) RETURNING id"""),
                            {"c": body.trayCode, "r": body.roomId, "a": body.row, "b": body.shelf, "d": body.slot}).scalar()
    except IntegrityError:
        raise AppError(409, "TRAY_CONFLICT", "Mã khay hoặc vị trí hàng/kệ/ô đã có khay")
    return {"id": str(tid)}


@router.patch("/trays/{tray_id}", summary="Sửa mã / vị trí khay (đổi phòng chỉ khi khay đang AVAILABLE)")
def update_tray(tray_id: str, body: TrayPatch, _=Depends(require_roles("ADMIN"))):
    try:
        with engine().begin() as c:
            tray = c.execute(text("SELECT * FROM trays WHERE id=:i FOR UPDATE"), {"i": tray_id}).first()
            if not tray:
                raise AppError(404, "TRAY_NOT_FOUND", "Khay không tồn tại")
            if body.roomId and str(tray.room_id) != body.roomId:
                if tray.occupancy_status == "RENTED":
                    raise AppError(409, "TRAY_RENTED", "Khay đang được thuê, không thể chuyển phòng")
                if not c.execute(text("SELECT 1 FROM rooms WHERE id=:i AND status='ACTIVE'"), {"i": body.roomId}).first():
                    raise AppError(404, "ROOM_NOT_FOUND", "Phòng không tồn tại")
            target_room = body.roomId or str(tray.room_id)
            target_row = body.row if body.row is not None else tray.location_row
            target_shelf = body.shelf if body.shelf is not None else tray.location_shelf
            target_slot = body.slot if body.slot is not None else tray.location_slot
            _lock_room_positions(c, [tray.room_id, target_room])
            _ensure_position_empty(c, target_room, target_row, target_shelf, target_slot, tray_id)
            c.execute(text("""UPDATE trays SET tray_code=COALESCE(:c,tray_code), room_id=COALESCE(CAST(:r AS uuid),room_id),
                              location_row=COALESCE(:a,location_row), location_shelf=COALESCE(:b,location_shelf),
                              location_slot=COALESCE(:d,location_slot) WHERE id=:i"""),
                      {"c": body.trayCode, "r": body.roomId, "a": body.row, "b": body.shelf, "d": body.slot, "i": tray_id})
            return _tray_row(c.execute(text(f"SELECT {_TRAY_COLS} FROM trays WHERE id=:i"), {"i": tray_id}).first())
    except IntegrityError:
        raise AppError(409, "TRAY_CONFLICT", "Mã khay hoặc vị trí hàng/kệ/ô đã có khay")


@router.delete("/trays/{tray_id}", status_code=204, summary="Xóa khay chưa từng thuê")
def delete_tray(tray_id: str, _=Depends(require_roles("ADMIN"))):
    with engine().begin() as c:
        if not c.execute(text("SELECT 1 FROM trays WHERE id=:i FOR UPDATE"), {"i": tray_id}).first():
            raise AppError(404, "TRAY_NOT_FOUND", "Khay không tồn tại")
        if c.execute(text("SELECT 1 FROM rental_trays WHERE tray_id=:i LIMIT 1"), {"i": tray_id}).first():
            raise AppError(409, "TRAY_HAS_HISTORY", "Khay đã từng được thuê, không thể xóa")
        c.execute(text("DELETE FROM trays WHERE id=:i"), {"i": tray_id})
